const app = Vue.createApp({
  // data, fuctions

  data() {
    return {
      jobs: [],
      checkboxes: [],
      search: "",
      // categories: [],
    };
  },
  methods: {
    async fetchUsers() {
      try {
        const res = await axios.get("https://reqres.in/api/users");
        this.jobs = res.data.data;
      } catch (err) {
        console.log(err);
      }
    },
  },

  mounted() {
    this.fetchUsers();
  },
  computed: {
    setOfCategories: function () {
      const category = this.jobs.map((job) => job.first_name);
      return new Set(category);
    },
    NumberOfCategory: function () {
      const category = this.jobs.map((job) => job.first_name);
      let categoryCount = [];
      category.map(function (i) {
        categoryCount[i] = (categoryCount[i] || 0) + 1;
      });
      console.log(Object.keys(categoryCount));

      return categoryCount;
    },
    setOfRegios: function () {
      const regios = this.jobs.map((job) => job.last_name);
      return new Set(regios);
    },
    filteredJobs: function () {
      if (this.search.replace(/\s+/g, " ").trim().length > 0) {
        return this.jobs.filter((job) => {
          return (
            job.first_name.toLowerCase().match(this.search.toLowerCase()) ||
            job.last_name.toLowerCase().match(this.search.toLowerCase())
          );
        });
      } else if (this.checkboxes.length > 0) {
        return this.jobs.filter((job) => {
          return Object.values(this.checkboxes).some(
            (box) =>
              box.toLowerCase() === job.first_name.toLowerCase() ||
              box.toLowerCase() === job.last_name.toLowerCase()
          );
        });
      } else {
        return this.jobs;
      }
    },
  },
});

app.mount("#app");
